package Principal;
import Ventanas.Juego;
import Ventanas.Login;
import Ventanas.Registro;

//Las variables o propiedades
public class Principal {


	/**
	 * ENTRADA A NUESTRO PROGRAMA
	 * ES EL METODO MAIN.
	 */
	public static void main(String[] args) {
		
			//Juego juego1 = new Juego();
			//Registro ventana = new Registro();
			Login ventanaLogin = new Login();
			ventanaLogin.setVisible(true);
		
	}

}
